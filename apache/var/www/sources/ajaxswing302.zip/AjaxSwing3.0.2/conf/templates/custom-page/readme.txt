Place your custom page templates here to keep them separate from default AjaxSwing templates

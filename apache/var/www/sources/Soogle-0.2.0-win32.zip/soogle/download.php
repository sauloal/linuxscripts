<?php
/**
 *  $Id: download.php,v 1.1 2005/04/03 23:45:10 pzhou Exp $
 */

/**
 *  Soogle - search over the google (http://soogle.sf.net)
 *  Copyright (C) 2005 Peter (Zhongyong Zhou) pzhou at sourceforge.net
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

 function Decrypt($string, $key)
{
$result = '';
for($i=1; $i<=strlen($string); $i++)
{
$char = substr($string, $i-1, 1);
$keychar = substr($key, ($i % strlen($key))-1, 1);
$char = chr(ord($char)-ord($keychar));
$result.=$char;
}
return $result;
}

function hex2bin($hexdata) {

   for ($i=0;$i<strlen($hexdata);$i+=2) {
     $bindata.=chr(hexdec(substr($hexdata,$i,2)));
   }
   return $bindata;
}

$root   = $_SERVER['DOCUMENT_ROOT'];

//$filename = "$root"."/download/".$_GET['file'];
$tmpname = $_GET['file'];
$filename = "";
if( $tmpname == "" ) {
   echo "<html><body>ERROR: Empty file to download. USE download.php?file=[file path]</body></html>";
   exit;
} else{
   $filename = Decrypt(hex2bin($tmpname), 'peter123');
   if ( ! file_exists( $filename ) ) {
    echo "<html><body>ERROR: File($filename) not found. USE download.php?file=[file path]</body></html>";
    exit;
   }
}
$ext = substr( $filename,-3 );
switch( $ext ){
   case "pdf": $ctype="application/pdf";              break;
   case "exe": $ctype="application/octet-stream";      break;
   case "zip": $ctype="application/zip";              break;
   case "doc": $ctype="application/msword";            break;
   case "xls": $ctype="application/vnd.ms-excel";      break;
   case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
   case "gif": $ctype="image/gif";                    break;
   case "png": $ctype="image/png";                    break;
   case "txt": $ctype="image/txt";                    break;
   case "jpg": $ctype="image/jpg";                    break;
   default:    $ctype="application/force-download";
}
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: $ctype");
$user_agent = strtolower ($_SERVER["HTTP_USER_AGENT"]);
if ((is_integer (strpos($user_agent, "msie"))) && (is_integer (strpos($user_agent, "win")))) {
   header( "Content-Disposition: filename=".basename($filename).";" );
} else {
   header( "Content-Disposition: attachment; filename=".basename($filename).";" );
}
header("Content-Transfer-Encoding: binary");
header("Content-Length: ".filesize($filename));
readfile("$filename");
exit();
?>
<?php
/**
 *  $Id: config.php,v 1.1 2005/04/03 23:45:10 pzhou Exp $
 */

/**
 *  Soogle - search over the google (http://soogle.sf.net)
 *  Copyright (C) 2005 Peter (Zhongyong Zhou) pzhou at sourceforge.net
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

// Google Desktop Search API URL,
//you can find this URL at HKEY_CURRENT_USER\Software\Google\Google Desktop\API
define('GDS_URL', 'http://127.0.0.1:4664/search&s=nqkA6lCVZGurXhdmbXQN1ZLAL5U');

// Number of results per page in Soogle
define('SGL_NUM', '10');

/* Stop editing */

$num = SGL_NUM;  //default results per page
$surl = GDS_URL; //GDS API URL
?>
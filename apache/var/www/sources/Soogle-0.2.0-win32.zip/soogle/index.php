<?php
/**
 *  $Id: index.php,v 1.2 2005/06/03 21:01:17 pzhou Exp $
 */

/**
 *  Soogle - search over the google (http://soogle.sf.net)
 *  Copyright (C) 2005 Peter (Zhongyong Zhou) pzhou at sourceforge.net
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */
?>
<html>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Soogle Search</title>
<?php
    include("config.php");
    $keyword = $_GET['keyword'];
    $start = $_GET['start'];
    if($start == "")
        $start = 0;
    $count = 0;  //number of results
?>

<?php

function Encrypt($string, $key)
{
$result = '';
for($i=1; $i<=strlen($string); $i++)
{
$char = substr($string, $i-1, 1);
$keychar = substr($key, ($i % strlen($key))-1, 1);
$char = chr(ord($char)+ord($keychar));
$result.=$char;
}
return $result;
}

function w32time2phptime ($filetime) {

  $win_secs = substr($filetime,0,strlen($filetime)-7); // divide by 10 000 000 to get seconds
  //$filetime / 10000000;
  $unix_timestamp = $win_secs;
  //($win_secs - 11644473600 - (4*365 + 46) *24*60*60) - 70 * 60; // 1.1.1600 -> 1.1.1970 difference in seconds
  return $unix_timestamp;
}

class xItem {
  var $xCategory;
  var $xTitle;
  var $xLink;
  var $xSnippet;
  var $xTime;
}

// general vars
$sNumber = "0";
$arItems = array();
$itemCount = 0;

// ********* Start User-Defined Vars ************
//$uFile = "http://127.0.0.1:4664/search&s=sM4cB4mYj8RIb-g9xpITuugTOpQ?q=zhou&num=5&start=20&format=xml";
// descriptions (true or false) goes here
$bDesc = true;
// font goes here
$uFont = "Verdana, Arial, Helvetica, sans-serif";
$uFontSize = 2;
// ********* End User-Defined Vars **************

function startElement($parser, $name, $attrs) {
  global $curTag, $sNumber;
  $numberKey = "COUNT";

  $curTag .= "^$name";
  if($curTag == "^RESULTS"){
      while(list($key, $value) = each($attrs)){
          if ($key == $numberKey) {
            $sNumber = $value;
          }
      }
  }

}

function endElement($parser, $name) {
  global $curTag;
  $caret_pos = strrpos($curTag,'^');
  $curTag = substr($curTag,0,$caret_pos);
}

function characterData($parser, $data) {
  global $curTag;
  // now get the items
  global $arItems, $itemCount;
  $xCategoryKey = "^RESULTS^RESULT^CATEGORY";
  $itemTitleKey = "^RESULTS^RESULT^TITLE";
  $itemLinkKey  = "^RESULTS^RESULT^URL";
  $itemTimeKey  = "^RESULTS^RESULT^TIME";
  $itemSnippetKey  = "^RESULTS^RESULT^SNIPPET";
  $itemIconKey  = "^RESULTS^RESULT^ICON";

  if ($curTag == $xCategoryKey) {
    // make new xItem
    $arItems[$itemCount] = new xItem();
    // set new item object's properties
    $arItems[$itemCount]->xCategory .= $data;
  } elseif ($curTag == $itemTitleKey) {
    $arItems[$itemCount]->xTitle .= $data;
  } elseif ($curTag == $itemLinkKey) {
    $arItems[$itemCount]->xLink .= $data;
  } elseif ($curTag == $itemSnippetKey) {
    $arItems[$itemCount]->xSnippet .= $data;
  } elseif ($curTag == $itemTimeKey) {
    $arItems[$itemCount]->$xTime .= $data;
  } elseif ($curTag == $itemIconKey) {
    // increment item counter
    $itemCount++;
  }
}

//function getURL($starttmp) {
    //return  $surl."q=".$keyword."&num=".$num."&start=".$starttmp."&format=xml";
//}

// main loop
// rss url goes here
if($keyword != ""){
    $uFile = $surl."?q=".$keyword."&num=".$num."&start=".$start."&format=xml";

    $xml_parser = xml_parser_create();
    xml_set_element_handler($xml_parser, "startElement", "endElement");
    xml_set_character_data_handler($xml_parser, "characterData");
    if (!($fp = fopen($uFile,"r"))) {
      die ("could not open RSS for input");
    }
    while ($data = fread($fp, 4096)) {
      if (!xml_parse($xml_parser, $data, feof($fp))) {
        die(sprintf("XML error: %s at line %d", xml_error_string(xml_get_error_code($xml_parser)), xml_get_current_line_number($xml_parser)));
      }
    }
    xml_parser_free($xml_parser);
    $count = $sNumber;
}
?>
<BODY>
<FORM  action="" method="GET" name="soogle">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="830" id="AutoNumber1" height="56">
  <tr>
    <td width="20%" rowspan="2" height="56">
          <img alt="Soogle" src="soogle.png" height="56">
    </td>
    <td width="2" rowspan="2" height="56" bgcolor="#11FF60"></td>
    <td width="50%" height="25"><font face = "<?php echo($uFont); ?>" size = "<?php echo($uFontSize); ?>"><b>Search the desktop remotely</b></font></td>
    <td width="30%" height="25"></td>
  </tr>
  <tr>
    <td width="50%" height="28" align="center">
    	<INPUT TYPE="TEXT" name="keyword" SIZE="60" ALIGN="Center" style="float: left" value="<?php echo $keyword;?>" onchange="window.document.soogle.start.value='0';">
    </td>
    <td width="30%" height="28">
        <INPUT TYPE="hidden"  name="start" ALIGN="Center" style="float: left" value="<?php echo $start;?>">
        <INPUT TYPE="submit"  name="search" ALIGN="Center" style="float: left" value=" Search ">
        <INPUT TYPE="reset"  name="clear" ALIGN="Center" style="float: left" value=" Clear ">
    </td>
  </tr>
</table>
</FORM>
<?php
if($keyword != ""){
?>
<font face = "<?php echo($uFont); ?>" size = "<?php echo($uFontSize); ?>" color = "green">Number of results:<?php echo($sNumber); ?></font>
<hr>
<?php
for ($i=0;$i<count($arItems);$i++) {
    $txItem = $arItems[$i];
    if($txItem->xCategory == "web"){
?>
    <font face = "<?php echo($uFont); ?>" size = "<?php echo($uFontSize); ?>"><b>Category: <?php echo ($txItem->xCategory.strftime("%c",$txItem->xTime));     ?>
    <br><?php echo ($txItem->xTitle); ?> </a>
    <br>Preview:</b> <!-- ?php echo ($txItem->xSnippet);? -->
    <br><br></font>
<?php
    }else{
?>
    <font face = "<?php echo($uFont); ?>" size = "<?php echo($uFontSize); ?>"><b>Category: <?php echo ($txItem->xCategory);     ?>
    &nbsp;<a href="download.php?file=<?php echo bin2hex(Encrypt($txItem->xLink,'peter123')); ?>" target="_new"> <?php echo $txItem->xTitle; ?> </a>
    <!-- ?php echo strftime("%c",w32time2phptime($txItem->xTime)); ? -->
    <br>Preview:</b> <?php echo ($txItem->xSnippet);?>
    <br><br></font>
<?php
    }
}

    print "<br>";
    print "<table border=0 cellpadding=0 width='1%' cellspacing=0 align=center style='font-family:Verdana;font-size:10.5pt'><tr align=center valign=top>";
    $page = $start/$num;
    $prefix = intval($start/(10*$num));

    //Previous link
    if($start >= $num){
        print "<td><a href=\"index.php?keyword=".$keyword."&start=".($start-$num) ."\">Previous</a></td>";
    }else{
        print "<td>Previous</td>";
    }

    //page link
    for($loop=0; ($loop*$num < $count) && ($loop < 10); $loop ++){
      $realpage = 10*$prefix + $loop + 1;
      if( (($realpage -1) * $num <= $start) && ($realpage * $num> $start) ){
          print "<td width=16>&nbsp;".$realpage."&nbsp;</td>";
      }else{
          print "<td width=16>&nbsp;<a href=\"index.php?keyword=".$keyword."&start=".(($realpage-1)*$num)."\">".$realpage."</a>&nbsp;</td>";
      }
    }

    //Next link
    if($start + $num < $count){
        print "<td><a href=\"index.php?keyword=".$keyword."&start=".($start+$num) ."\">Next</a></td>";
    }else{
      print "<td>Next</td>";
    }
    print "</tr></table>";
}
?>
<center><p><font face="<?php echo($uFont); ?>" size=-1>Powered by <a href="http://soogle.sf.net" target="_new">Soogle</a> Under copyright of GPL</font></p></center>
</BODY>
</html>